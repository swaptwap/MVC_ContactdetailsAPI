﻿using ContactswithWebAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;

namespace ContactswithWebAPI.Controllers
{
    public class ContactApiController : ApiController
    {
        private readonly IContactRepository _iEmployeeRepository = new ContactRepository();

        [HttpGet]
        [Route("api/Contact/Get")]
        public async Task<IEnumerable<Contact>> Get()
        {
            return await _iEmployeeRepository.GetEmployees();
        }

        [HttpPost]
        [Route("api/Contact/Create")]
        public async Task CreateAsync([FromBody]Contact employee)
        {
            if (ModelState.IsValid)
            {
                await _iEmployeeRepository.Add(employee);
            }
        }

        [HttpGet]
        [Route("api/Contact/Details/{id}")]
        public async Task<Contact> Details(string id)
        {
            var result = await _iEmployeeRepository.GetEmployee(id);
            return result;
        }

        [HttpPut]
        [Route("api/Contact/Edit")]
        public async Task EditAsync([FromBody]Contact employee)
        {
            if (ModelState.IsValid)
            {
                await _iEmployeeRepository.Update(employee);
            }
        }

        [HttpDelete]
        [Route("api/Contact/Delete/{id}")]
        public async Task DeleteConfirmedAsync(string id)
        {
            await _iEmployeeRepository.Delete(id);
        }
    }
}