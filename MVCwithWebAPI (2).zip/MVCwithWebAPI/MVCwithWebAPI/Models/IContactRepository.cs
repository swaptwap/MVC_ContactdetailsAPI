﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace ContactswithWebAPI.Models
{
    public interface IContactRepository
    {
        Task Add(Contact employee);
        Task Update(Contact employee);
        Task Delete(string id);
        Task<Contact> GetEmployee(string id);
        Task<IEnumerable<Contact>> GetEmployees();
    }
}
