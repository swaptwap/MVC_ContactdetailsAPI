﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace ContactswithWebAPI.Models
{
    public class ContactRepository : IContactRepository
    {
        private readonly SqlDbContext db = new SqlDbContext();
        public async Task Add(Contact employee)
        {
            employee.Id = Guid.NewGuid().ToString();
            db.Contacts.Add(employee);
            try
            {
                await db.SaveChangesAsync();
            }
            catch
            {
                throw;
            }
        }
        public async Task<Contact> GetEmployee(string id)
        {
            try
            {
                Contact employee = await db.Contacts.FindAsync(id);
                if (employee == null)
                {
                    return null;
                }
                return employee;
            }
            catch
            {
                throw;
            }
        }
        public async Task<IEnumerable<Contact>> GetEmployees()
        {
            try
            {
                var employees = await db.Contacts.ToListAsync();
                return employees.AsQueryable();
            }
            catch
            {
                throw;
            }
        }
        public async Task Update(Contact employee)
        {
            try
            {
                db.Entry(employee).State = EntityState.Modified;
                await db.SaveChangesAsync();
            }
            catch
            {
                throw;
            }
        }
        public async Task Delete(string id)
        {
            try
            {
                Contact employee = await db.Contacts.FindAsync(id);
                db.Contacts.Remove(employee);
                await db.SaveChangesAsync();
            }
            catch
            {
                throw;
            }
        }

        private bool EmployeeExists(string id)
        {
            return db.Contacts.Count(e => e.Id == id) > 0;
        }

    }
}